#include <stdio.h>
#include "reg.h"

int main(){
    regB();
    regS();
    
    return 0;
}