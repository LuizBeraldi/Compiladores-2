#ifndef REGALLOC_REG_H
#define REGALLOC_REG_H

void regB();
void regS();

#endif